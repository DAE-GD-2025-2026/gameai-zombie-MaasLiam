﻿#include "ZombieAgentBrainComponent.h"

#include "GameFramework/Pawn.h"
#include "StudentPerceptor.h"
#include "ZombieInventoryHelper.h"
#include "ZombieThreatHelper.h"
#include "ZombieExplorationHelper.h"
#include "ZombieCombatHelper.h"
#include "ZombieSurvivorStatusHelper.h"
#include "ZombieMovementHelper.h"

UZombieAgentBrainComponent::UZombieAgentBrainComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UZombieAgentBrainComponent::BeginPlay()
{
	Super::BeginPlay();

	Perceptor = GetOwner()->FindComponentByClass<UStudentPerceptor>();
	InventoryComponent = FZombieSurvivorStatusHelper::FindComponentByNamePart(GetOwner(), TEXT("Inventory"));
	HealthComponent = FZombieSurvivorStatusHelper::FindComponentByNamePart(GetOwner(), TEXT("Health"));
	StaminaComponent = FZombieSurvivorStatusHelper::FindComponentByNamePart(GetOwner(), TEXT("Stamina"));
}

void UZombieAgentBrainComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	UpdateState();
	ExecuteCurrentState(DeltaTime);

	GEngine->AddOnScreenDebugMessage(
		20,
		0.f,
		FColor::Cyan,
		FString::Printf(TEXT("AI State: %s"), *GetStateName())
	);
}

void UZombieAgentBrainComponent::UpdateState()
{
	AActor* ClosestZombie = FZombieThreatHelper::GetClosestZombie(Perceptor, GetOwner());

	if (ClosestZombie)
	{
		const float ZombieDistance = FVector::Dist(GetOwner()->GetActorLocation(), ClosestZombie->GetActorLocation());

		if (ZombieDistance <= ZombieFightRange)
		{
			CurrentState = EZombieAgentState::Fight;
			return;
		}

		if (CurrentState == EZombieAgentState::Flee)
		{
			if (ZombieDistance <= ZombieDangerExitRange)
			{
				CurrentState = EZombieAgentState::Flee;
				return;
			}
		}
		else if (ZombieDistance <= ZombieDangerEnterRange)
		{
			CurrentState = EZombieAgentState::Flee;
			return;
		}
	}

	if (FZombieSurvivorStatusHelper::ShouldUseItem(InventoryComponent, HealthComponent, StaminaComponent, LowHealthThreshold, LowStaminaThreshold))
	{
		CurrentState = EZombieAgentState::UseItem;
		return;
	}

	
	AActor* ClosestPurgeZone = FZombieThreatHelper::GetClosestPurgeZone(Perceptor, GetOwner());

	if (ClosestPurgeZone)
	{
		const float PurgeDistance = FVector::Dist(
			GetOwner()->GetActorLocation(),
			ClosestPurgeZone->GetActorLocation()
		);

		if (PurgeDistance <= PurgeDangerRange)
		{
			CurrentState = EZombieAgentState::AvoidPurge;
			return;
		}
	}

	if (FZombieInventoryHelper::GetBestItem(Perceptor, GetOwner()))
	{
		CurrentState = EZombieAgentState::SeekItem;
		return;
	}
	
	if (FZombieExplorationHelper::GetClosestUnsearchedHouse(Perceptor, GetOwner(), SearchedHouses))
	{
		CurrentState = EZombieAgentState::SearchHouse;
		return;
	}

	CurrentState = EZombieAgentState::Explore;
}

void UZombieAgentBrainComponent::ExecuteCurrentState(float DeltaTime)
{
	switch (CurrentState)
	{
	case EZombieAgentState::Explore:
		ExecuteExplore(DeltaTime);
		break;

	case EZombieAgentState::SeekItem:
		ExecuteSeekItem();
		break;

	case EZombieAgentState::Flee:
		ExecuteFlee();
		break;

	case EZombieAgentState::UseItem:
		ExecuteUseItem();
		break;
		
	case EZombieAgentState::Fight:
		ExecuteFight(DeltaTime);
		break;
		
	case EZombieAgentState::SearchHouse:
		ExecuteSearchHouse();
		break;
		
	case EZombieAgentState::AvoidPurge:
		ExecuteAvoidPurge();
		break;

	default:
		break;
	}
}

void UZombieAgentBrainComponent::ExecuteExplore(float DeltaTime)
{
	TimeSinceLastExploreMove += DeltaTime;

	if (TimeSinceLastExploreMove < ExploreMoveInterval)
	{
		return;
	}

	TimeSinceLastExploreMove = FMath::FRandRange(-1.5f, 0.f);
	FZombieMovementHelper::MoveToLocation(GetOwner(), FZombieExplorationHelper::GetRandomExploreLocation(GetOwner(), ExploreRadius), 100.f);
}

void UZombieAgentBrainComponent::ExecuteSeekItem()
{
	AActor* ClosestItem = FZombieInventoryHelper::GetBestItem(Perceptor, GetOwner());
	if (!ClosestItem) return;
	
	if (FZombieInventoryHelper::IsInventoryFull(InventoryComponent))
	{
		if (FZombieInventoryHelper::TryReplaceInventoryItem(InventoryComponent, Perceptor, ClosestItem))
		{
			return;
		}
	}

	if (FZombieInventoryHelper::TryPickupItem(GetOwner(), InventoryComponent, Perceptor, ClosestItem))
	{
		return;
	}

	FZombieMovementHelper::MoveToActor(GetOwner(), ClosestItem, 25.f);
}

void UZombieAgentBrainComponent::ExecuteFlee()
{
	AActor* ClosestZombie = FZombieThreatHelper::GetClosestZombie(Perceptor, GetOwner());
	if (!ClosestZombie) return;

	FZombieMovementHelper::MoveToLocation(GetOwner(), FZombieThreatHelper::GetFleeLocation(Perceptor, GetOwner(), FleeDistance), 100.f);
	GEngine->AddOnScreenDebugMessage(-1, 0.f, FColor::Red, TEXT("FLEEING FROM ZOMBIE"));
}

void UZombieAgentBrainComponent::ExecuteUseItem()
{
	if (FZombieSurvivorStatusHelper::TryUseInventoryItem(InventoryComponent, HealthComponent, StaminaComponent, LowHealthThreshold, LowStaminaThreshold))
	{
		GEngine->AddOnScreenDebugMessage(-1, 2.f, FColor::Green, TEXT("Used inventory item"));
	}
}

FString UZombieAgentBrainComponent::GetStateName() const
{
	switch (CurrentState)
	{
	case EZombieAgentState::Explore:
		return "Explore";
	case EZombieAgentState::SeekItem:
		return "SeekItem";
	case EZombieAgentState::Flee:
		return "Flee";
	case EZombieAgentState::Fight:
		return "Fight";
	case EZombieAgentState::UseItem:
		return "UseItem";
	case EZombieAgentState::SearchHouse:
		return "SearchHouse";
	case EZombieAgentState::AvoidPurge:
		return "AvoidPurge";
	default:
		return "Unknown";
	}
}

void UZombieAgentBrainComponent::ExecuteFight(float DeltaTime)
{
	TimeSinceLastWeaponUse += DeltaTime;

	AActor* ClosestZombie = FZombieThreatHelper::GetClosestZombie(Perceptor, GetOwner());
	if (!ClosestZombie)
	{
		return;
	}
	
	FZombieMovementHelper::FaceActor(GetOwner(), ClosestZombie);

	if (TimeSinceLastWeaponUse >= WeaponUseInterval)
	{
		TimeSinceLastWeaponUse = 0.f;

		if (FZombieCombatHelper::TryUseWeapon(InventoryComponent))
		{
			GEngine->AddOnScreenDebugMessage(-1, 1.f, FColor::Purple, TEXT("FIGHT: used weapon"));
			return;
		}
	}
	ExecuteFlee();
}
void UZombieAgentBrainComponent::ExecuteSearchHouse()
{
	AActor* ClosestHouse = FZombieExplorationHelper::GetClosestUnsearchedHouse(Perceptor, GetOwner(), SearchedHouses);
	if (!ClosestHouse) return;
	
	const float DistanceToHouse = FVector::Dist(GetOwner()->GetActorLocation(), ClosestHouse->GetActorLocation());

	if (DistanceToHouse <= HouseSearchAcceptanceRadius + 100.f)
	{
		if (!SearchedHouses.Contains(ClosestHouse))
		{
			SearchedHouses.Add(ClosestHouse);
		}
		
		if (Perceptor)
		{
			Perceptor->SeenHouses.Remove(ClosestHouse);
		}

		GEngine->AddOnScreenDebugMessage(
			-1,
			2.f,
			FColor::Blue,
			TEXT("Finished searching house")
		);

		return;
	}

	FZombieMovementHelper::MoveToActor(GetOwner(), ClosestHouse, HouseSearchAcceptanceRadius);
	GEngine->AddOnScreenDebugMessage(-1, 1.f, FColor::Blue, TEXT("Searching house"));
}

void UZombieAgentBrainComponent::ExecuteAvoidPurge()
{
	AActor* ClosestPurgeZone = FZombieThreatHelper::GetClosestPurgeZone(Perceptor, GetOwner());
	if (!ClosestPurgeZone) return;

	FZombieMovementHelper::MoveToLocation(GetOwner(), FZombieThreatHelper::GetPurgeAvoidanceLocation(GetOwner(), ClosestPurgeZone, PurgeFleeDistance), 100.f);
	GEngine->AddOnScreenDebugMessage(-1, 1.f, FColor::Purple, TEXT("Avoiding purge zone"));
}